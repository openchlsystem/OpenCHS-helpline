<?php
class App{
	var $view_array = array();
	var $ctrl,$ur,$controlled,$title,$description,$obj,$settings,$locations,$db2;
	private $urstr,$root;
	function __construct(){
		$this->obj = new QUERY(HOST,DB_NAME);
		
		//routing
		$this->urstr = $_SERVER['REQUEST_URI'];
		$this->root = strtolower(ROOT);
		$this->urstr = strpos($this->urstr, 'index.php') ? str_replace($this->root.'index.php/', "", strtolower($this->urstr)) : $this->urstr;
		
		if($this->root !== '/'){
			$this->urstr = str_replace($this->root, "", strtolower($this->urstr));
		}


		$params  = array_filter(explode("/", $this->urstr)); ///get parameters
		
		$this->args = array_splice($params,1,sizeof($params)-1);

		$this->ur = empty($params) ? 'home' : $params[0];		

		$this->view_array = array('report','faqs','api');
		$this->ctrl = $this->ur;
		$this->controlled = !in_array($this->ur, $this->view_array) ? true : false;
		$this->ctrl = !$this->controlled ? $this->ur : 'default';

		$this->settings = array('home'=>array('title'=>'.','description'=>'','tags'=>''));

		if(isset($this->settings[$this->ur])){
			$this->title= $this->settings[$this->ur]['title'];
			$this->description= $this->settings[$this->ur]['description'];
		}else{
			$this->title= $this->settings['home']['title'];
			$this->description= $this->settings['home']['description'];
		}
		///get default data

        // $query = 'select DISTINCT level1_code,level1_name from tbl_locations'; 
        // $this->locations = $this->obj->getAll($query);
        // return json_encode($this->locations);
        // die(json_encode($this->locations));
	}


	function get_uri(){
		return $this->ur;
	}


	function controller(){
		$fl = CONTROLS.'ctrl_'.$this->ctrl.EXT;
		if(file_exists($fl))
			return $fl;
		else{
			$this->ur = '404';
			$this->controlled = true;
			return CONTROLS.'ctrl_home'.EXT;
		}
	}


	function current_uri($ur){		
		$fl = VIEWS.$ur.EXT;
		if(file_exists($fl))
			return $fl;
		else{
			return VIEWS.'404'.EXT;
		}
	}
}