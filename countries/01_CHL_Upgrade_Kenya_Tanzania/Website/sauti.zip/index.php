<?php

$config = __DIR__."/inc/";
require $config.'const.html';
require $config. 'app.php';
$app = new App();

!$app->controlled ? require $app->controller():'';

$current = str_replace("-", "", $app->ur);
!$app->controlled ? $currentObject = new $current():"";
require VIEWS.'header.html';
require $app->current_uri($app->ur);
require VIEWS.'footer.html';
?>