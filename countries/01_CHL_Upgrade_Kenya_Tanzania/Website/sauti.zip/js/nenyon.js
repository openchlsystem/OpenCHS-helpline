// JavaScript Document
let colors = ["#BD3DB6","#04C027","#580BD9","#6E8443",	"#EEB95F","#B5C202","#48AA7F","#F9C809","#DB7BBC","#E09901","#F3690C","#0AFB12","#46FFD7","#1D36EE","#96637F","#CD2D2F","#A6C36B","#0C5804","#0BCE87","#702896","#A4B145","#3A9223","#2634C1","#DA79BA","#389137","#E17E1F","#597A80","#F95F4D","#9778D3","#ADFC38","#2DA2C8","#60A4F4","#2811CA","#A777D1","#19EF71","#93CE39","#84A63E","#163269","#6B38B9","#D966A2","#0B8815","#8676D6","#767301","#E983D1","#5D2A82","#E668AA","#A8116D","#9A743B","#869DEE","#5F6AB8","#76A26C","#474230","#140C3C","#FC7F66","#D3DD3B","#943908","#390B94","#1D6039","#B1D5A2","#D98F69","#78E769","#EAD5A5","#E3C4CE","#992F38","#FB6E96","#1B490A","#14DEFD","#FF5A5E","#C9485D","#343ACF","#A58114","#B7804F","#C0E3CA","#CE6698","#22FB50","#BF92B1","#25B56B","#84D93F","#D4AD36","#9D0B96","#64B6D1","#FC05FB","#D67DC1","#F3ED90","#DD3B1F","#92B718","#2E4E46","#5B745D","#55E72F","#CCEAF4","#27C145","#0C9E27","#46CB1A","#A84A3F","#8AB282","#D8071F"]
var perpetrator = function(th){
	if(!$(th).is(':checked')){
		$('#perpetrator').find('input,select,textarea').each(function(e){
			if($(this).attr('required')) $(this).attr('required',false)
		})
	}else{
		['perp_name','perp_gender','perp_landmark'].forEach(function(item){
			if(!$('#'+item).attr('required')) $('#'+item).attr('required',true)
		})
	}
}
function locations(){
	$.get("report/locations/level1/").then(function(response){
		return response;
	})
}
$(document).ready(function(e){

	$("#select_location").autocomplete	({
      source: function( request, response ) {
      	$.ajax({
            url: "report/locations/" + request.term,
            dataType: "json",
            success: function(data){
            	response(data)
            }//response is a callable accepting data parameter. no reason to wrap in anonymous function.
        });
      	},
	    select: function( event, ui ) {
	      $("#select_location").val("Region: " + ui.item.region + ", District: " + ui.item.district + " Parish: " + ui.item.parish + ", Village: " + ui.item.village);
	      //$( "#project-id" ).val( ui.item.value );
	      $("#reporter_location").val( ui.item.level6_code );

	      return false;
	    },
        create: function (event,ui){
	       $(this).data('ui-autocomplete')._renderItem = function (ul, item) {
	        return $( "<li class='d-flex'>" )
			    .attr( "data-value", item.level6_code )
			    .append("Region: " + item.region + ", District: " + item.district + " <br /> Parish: " + item.parish + ", Village: " + item.village )
			    .appendTo(ul);
			    ul.addClass('list-unstyled mb-0')
            };
        }
		,
		"minLength": 5,
		classes: {
		    "ui-autocomplete": "highlight"
		}
    })

})

$('#casecapture').submit(function(e){
	e.preventDefault()
	var th = this
	var casedetails = {}

	$.post("report/",$(this).serialize()).then(function(response){
		$(th)[0].reset()
		$(th).after('<div class="alert alert-success caseform" role="alert">' +
            response + '</div>')

		setTimeout(function(){
			$(".caseform").remove()
			ne_init($nenyonwizard)
			$('.close').click()
			$('#perpetrator').hide();
			$('#case_report').hide()
		},1500)

		
	}).fail(function(response){
			$(th).after('<div class="alert alert-danger caseform" role="alert">' +
                response + '</div>')
		setTimeout(function(){
			$(".caseform").remove()
		},1500)

	})
})

$("#chIsClient").on("change",function(){
	if($(this).is(":checked")){
		$('#client_name').val($('#reporter_name').val())
		$('#client_gender').val($('#reporter_gender').val())
		$('#client_location').val($('#reporter_location').val())
		$('#client_landmark').val($('#reporter_landmark').val())
		$('#select_client_location').val($('#select_location').val())

	}
})

function load_data(start=false,end=false,region=false){
	var str = moment(start, "DD/MM/YYYY hh:mm A")/1000 + "/" + moment(end, "DD/MM/YYYY hh:mm A")/1000 + "/" //.format("DD-MM-YYYY hh:mm A")
	str += region == false ? "" : region + "/"
	$.get("report/reports/" + str).then(function(response){
		var response = JSON.parse(response)
		barchart(response.per_month)
		loadpie(response.per_category)
		////for age gender
		var d = {"yaxis":"Case Count","container":"gender-stacked","data":response.per_category_gender,"title":"Case Categories per Gender"}
		loadStacked(d)	
		////for age groups
		var d = {"yaxis":"Case Count","container":"age-group-stacked","data":response.per_category_age,"title":"Case Categories per Age Group"}
		loadStacked(d)
	}).fail(function(response){
		console.log("Data Error: " + response)
	})
}

$('#reportdrange,#reportregion').change(function(){
	var [start,end] = $('#reportdrange').val().split(" - ")
	var region_value = $("#reportregion").val()
	region_value =  region_value == "" ? false : region_value
	load_data(start,end,region_value)

})
/////charts
function barchart(data){
	/* Basic column */
	var chData = {}

 	data.forEach(function(item,index){
 		var reg = item.region
 		if(reg == null){
 			reg = "Others"
 		}

 		if(!chData[reg]){
 			chData[reg] = {"name":reg,"color":colors[index],"data":[]}
 			chData[reg].data = Array(12).fill(1).map(x => 0)
 		}
 		chData[reg].data[item.dc-1] = item.cc
 	})

 	var data = Object.keys(chData).map(da=>chData[da])

 	////the x-axis params
 	//get selected date and difference
 	var [start,end] = $('#reportdrange').val().split(" - ")

 	const date1 = moment(start, "DD/MM/YYYY hh:mm A");
	const date2 = moment(end, "DD/MM/YYYY hh:mm A");
	const diffTime = date2.diff(date1)
	const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24)); 

	
	var periodintervals = [
                'Jan',
                'Feb',
                'Mar',
                'Apr',
                'May',
                'Jun',
                'Jul',
                'Aug',
                'Sep',
                'Oct',
                'Nov',
                'Dec'
            ]


	$('#basic-column').highcharts({
        chart: {
            type: 'column'
        },
        title: {
            text: 'Cases Per Region'
        },
        subtitle: {
            text: 'Period: ' + $('#reportdrange').val()
        },
        xAxis: {
            categories: periodintervals
        },
        yAxis: {
            min: 0,
            title: {
                text: 'Number of Cases (Count)'
            }
        },
        tooltip: {
            headerFormat: '<span style="font-size:12px">{point.key}</span><table>',
            pointFormat: '<tr><td style="color:{series.color};padding:0;font-size:14px">{series.name}: </td>' +
                '<td style="padding:0;display:inline;font-size:14px">{point.y}</td></tr>',
            footerFormat: '</table>',
            shared: true,
            useHTML: true
        },
        plotOptions: {
            column: {
                pointPadding: 0.2,
                borderWidth: 0
            }
        },
        series: data
    });

      
}

function loadpie(data){

 	var data = Object.keys(data).map((k)=>[data[k].dc == null ? "Other" :data[k].dc.toString(),data[k].cc])
	/* Pie Chart */
      $('#pie-chart').highcharts({
	      chart: {
	            plotBackgroundColor: null,
	            plotBorderWidth: null,
	            plotShadow: false
	      },
	      title: {
	            text: 'Cases Per Category'
	      },
	      tooltip: {
	            pointFormat: '{series.name}: <b>{point.percentage:.1f}%</b>'
	      },
	      plotOptions: {
	            pie: {
	                allowPointSelect: true,
	                cursor: 'pointer',
	                dataLabels: {
	                    enabled: true,
	                    color: '#000000',
	                    connectorColor: '#000000',
	                    format: '<b>{point.name}</b>: {point.percentage:.1f} %'
	                	}	
	            }
	      },
	      series: [{
	            type: 'pie',
	            name: 'Browser share',
	            data: data
	      }]
	});
}

function loadStacked(data){

	var chData = {}
	var ages = []
	var vdata = data;
	console.log("DDD: "+JSON.stringify((data)))
	data.data.forEach(function(item,index){
 		var cat = item.dcc
 		if(cat == null){
 			cat = "Others"
 		}

 		if(!chData[cat]){
 			chData[cat] = {"name":cat,"color":colors[index],"data":[]}
 			chData[cat].data = Array(12).fill(1).map(x => 0) //value 7 needs to be dynamic
 		}


 		var age_group = item.categorie == null ? "Others" : item.categorie
 		
 		if(ages.indexOf(age_group) == -1){
 			ages.push(age_group)
 		}
 		var age_g = ages.indexOf(age_group)
 		if(cat != null && cat != 0)
	 		chData[cat].data[age_g] = item.cc

 	})
 	// data.data.forEach(function(item,index){
 	// 	var cat = item.dcc
 	// 	if(cat == null){
 	// 		cat = "Others"
 	// 	}


 	// 	var age_group = item.categorie == null ? "Others" : item.categorie
 		
 	// 	if(ages.indexOf(age_group) == -1){
 	// 		ages.push(age_group)
 	// 	}
 	// 	var age_g = ages.indexOf(age_group)
 	// 	if(cat != null && cat != 0)
	 // 		chData[cat].data[age_g] = item.cc

 	// })

 	var data = Object.keys(chData).map(da=>chData[da])

	
	$("#" + vdata.container).highcharts({
		chart: {
			type: 'column'
		},
		title: {
			text: vdata.title
		},
		xAxis: {
			categories: ages // ['Apples', 'Oranges', 'Pears', 'Grapes', 'Bananas']
		},
		yAxis: {
			min: 0,
			title: {
				text: vdata.yaxis
			},
			stackLabels: {
				enabled: true,
				style: {
					fontWeight: 'bold',
					color: (Highcharts.theme && Highcharts.theme.textColor) || 'gray'
				}
			}
		},
		legend: {
			align: 'right',
			x: -70,
			verticalAlign: 'top',
			y: 20,
			floating: true,
			backgroundColor: (Highcharts.theme && Highcharts.theme.legendBackgroundColorSolid) || 'white',
			borderColor: '#CCC',
			borderWidth: 1,
			shadow: false
		},
		tooltip: {
			formatter: function() {
				return '<b>'+ this.x +'</b><br/>'+
				this.series.name +': '+ this.y +'<br/>'+
				'Total: '+ this.point.stackTotal;
			}
		},
		plotOptions: {
			column: {
				stacking: 'normal',
				dataLabels: {
					enabled: true,
					color: (Highcharts.theme && Highcharts.theme.dataLabelsColor) || 'white'
				}
			}
		},
		series: data
	});
}

