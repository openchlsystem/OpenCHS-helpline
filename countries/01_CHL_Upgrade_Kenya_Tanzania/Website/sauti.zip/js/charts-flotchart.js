$(function () {
    //BEGIN PIE CHART
    var d = [["","35"],["Case Update","3"],["Child Neglect","5"],["Economic Violence","1"],["Emotional & Psychological Abuse","2"],["Lost Child","1"],["Online Sexual Abuse & Violence","2"],["Physical Violence","4"],["Sexual Violence","13"],["Topical Issues (Child rights, Biology etc)","3"],["Trafficking in Persons","1"]]
    var color = Math.floor(Math.random()*16777215).toString(16);
    var data = []

    d.forEach(function(item,index){
        var cl = '#' + Math.floor(Math.random()*16777215).toString(16);
        if(item[1] !== "")
            data.push({data:[parseInt(item[1])],label:item[0],color:cl})
    })
   
    $.plot('#pie-chart',data, {
    series: {
        pie: {
            show: true,
            radius: 1,
            label: {
                show: false,
                radius: 3/4,
                background: {
                    opacity: 0.3,
                    color: '#000'
                }
            }
        }
    }
    });
    //END PIE CHART


});

