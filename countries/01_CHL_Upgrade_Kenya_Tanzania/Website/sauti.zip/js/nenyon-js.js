// JavaScript Document

var ne_init = function($nenyonwizard){
	$nenyonwizard.children('fieldset').each(function(index, element) {
		if(index > 0)
		    $(this).hide();
		else{
			if(!$(this).is(':visible'))
				$(this).show();
		}
	})
}
$nenyonwizard = $('.nenyon-wizard');
ne_init($nenyonwizard);
$nenyonwizard.find('.next').each(function(index, element) {
    $(this).click(function(){
    	var $invalid = false

    	$nenyonwizard.children('fieldset').eq(index).find('input,select,textarea').each(function(index,item){
    		if(!$(this).is(':valid') && $(this).attr('type') != 'hidden'){
    			$invalid = true;
    			if($(this).hasClass('is-valid')) $(this).removeClass('is-valid')
    			if(!$(this).hasClass('is-invalid')) $(this).addClass('is-invalid')
    		}else{
    			if(!$(this).hasClass('is-valid')) $(this).addClass('is-valid')
    			if($(this).hasClass('is-invalid')) $(this).removeClass('is-invalid')    			
    		}
    	})

    	if($invalid){
    		return false;
    	}else{
			$nenyonwizard.children('fieldset').eq(index).hide()
			$nenyonwizard.children('fieldset').eq(index + 1).show()
    	}

	})
});

$nenyonwizard.find('.previous').each(function(index, element) {
    $(this).click(function(){
		$nenyonwizard.children('fieldset').eq(index + 1).hide()
		$nenyonwizard.children('fieldset').eq(index).show()
	})
});

window.dd = [
  {
    "dcc": "^Parent or Child Relationship",
    "categorie": "^Female",
    "cc": 16
  },
  {
    "dcc": "^Parent or Child Relationship",
    "categorie": "^Male",
    "cc": 8
  },
  {
    "dcc": "^Parental Guidance",
    "categorie": "^Female",
    "cc": 1
  },
  {
    "dcc": "^Physical Violence",
    "categorie": "",
    "cc": 2
  },
  {
    "dcc": "^Physical Violence",
    "categorie": "^Female",
    "cc": 194
  },
  {
    "dcc": "^Physical Violence",
    "categorie": "^Male",
    "cc": 164
  },
  {
    "dcc": "^Physical Violence",
    "categorie": "^Unknown",
    "cc": 3
  },
  {
    "dcc": "^Property_Rights",
    "categorie": "^Female",
    "cc": 30
  },
  {
    "dcc": "^Property_Rights",
    "categorie": "^Male",
    "cc": 15
  },
  {
    "dcc": "^Reproductive Health Issues",
    "categorie": "^Female",
    "cc": 1
  },
  {
    "dcc": "^Reproductive Health Issues",
    "categorie": "^Male",
    "cc": 1
  },
  {
    "dcc": "^Run Away Child",
    "categorie": "^Female",
    "cc": 3
  },
  {
    "dcc": "^Run Away Child",
    "categorie": "^Male",
    "cc": 6
  },
  {
    "dcc": "^Sexual Violence",
    "categorie": "",
    "cc": 1
  },
  {
    "dcc": "^Sexual Violence",
    "categorie": "^Female",
    "cc": 206
  },
  {
    "dcc": "^Sexual Violence",
    "categorie": "^Male",
    "cc": 12
  },
  {
    "dcc": "^Street Child",
    "categorie": "^Male",
    "cc": 1
  },
  {
    "dcc": "^Topical Issues (Child rights, Biology etc)",
    "categorie": "",
    "cc": 3
  },
  {
    "dcc": "^Topical Issues (Child rights, Biology etc)",
    "categorie": "^Female",
    "cc": 18
  },
  {
    "dcc": "^Topical Issues (Child rights, Biology etc)",
    "categorie": "^Male",
    "cc": 19
  },
  {
    "dcc": "^Topical Issues (Child rights, Biology etc)",
    "categorie": "^Unknown",
    "cc": 3
  },
  {
    "dcc": "^Trafficking in Persons",
    "categorie": "^Female",
    "cc": 32
  },
  {
    "dcc": "^Trafficking in Persons",
    "categorie": "^Male",
    "cc": 11
  }
]
















window.ddd = [
  {
    "categorie": null,
    "dcc": "^05-09",
    "cc": 1
  },
  {
    "categorie": "",
    "dcc": "^05-09",
    "cc": 1
  },
  {
    "categorie": "",
    "dcc": "^10-13",
    "cc": 1
  },
  {
    "categorie": "",
    "dcc": "^14-17",
    "cc": 2
  },
  {
    "categorie": "",
    "dcc": "^31-45",
    "cc": 1
  },
  {
    "categorie": "^Appreciation",
    "dcc": "",
    "cc": 1
  },
  {
    "categorie": "^Boy\\\\\\/Girl Relationship",
    "dcc": "",
    "cc": 1
  },
  {
    "categorie": "^Boy\\\\\\/Girl Relationship",
    "dcc": "^18-24",
    "cc": 1
  },
  {
    "categorie": "^Career Guidance",
    "dcc": "",
    "cc": 1
  },
  {
    "categorie": "^Career Guidance",
    "dcc": "^18-24",
    "cc": 1
  },
  {
    "categorie": "^Case Update",
    "dcc": "",
    "cc": 9
  },
  {
    "categorie": "^Case Update",
    "dcc": "^0-04",
    "cc": 1
  },
  {
    "categorie": "^Case Update",
    "dcc": "^05-09",
    "cc": 3
  },
  {
    "categorie": "^Case Update",
    "dcc": "^10-13",
    "cc": 1
  },
  {
    "categorie": "^Case Update",
    "dcc": "^14-17",
    "cc": 2
  },
  {
    "categorie": "^Child Custody",
    "dcc": "",
    "cc": 105
  },
  {
    "categorie": "^Child Custody",
    "dcc": "^0-04",
    "cc": 38
  },
  {
    "categorie": "^Child Custody",
    "dcc": "^05-09",
    "cc": 55
  },
  {
    "categorie": "^Child Custody",
    "dcc": "^10-13",
    "cc": 16
  },
  {
    "categorie": "^Child Custody",
    "dcc": "^14-17",
    "cc": 8
  },
  {
    "categorie": "^Child Custody",
    "dcc": "^31-45",
    "cc": 1
  },
  {
    "categorie": "^Child Exploitation",
    "dcc": "",
    "cc": 12
  },
  {
    "categorie": "^Child Exploitation",
    "dcc": "^05-09",
    "cc": 6
  },
  {
    "categorie": "^Child Exploitation",
    "dcc": "^10-13",
    "cc": 21
  },
  {
    "categorie": "^Child Exploitation",
    "dcc": "^14-17",
    "cc": 9
  },
  {
    "categorie": "^Child In Conflict with the Law",
    "dcc": "",
    "cc": 10
  },
  {
    "categorie": "^Child In Conflict with the Law",
    "dcc": "^14-17",
    "cc": 4
  },
  {
    "categorie": "^Child Neglect",
    "dcc": "",
    "cc": 765
  },
  {
    "categorie": "^Child Neglect",
    "dcc": "^0-04",
    "cc": 204
  },
  {
    "categorie": "^Child Neglect",
    "dcc": "^05-09",
    "cc": 185
  },
  {
    "categorie": "^Child Neglect",
    "dcc": "^10-13",
    "cc": 104
  },
  {
    "categorie": "^Child Neglect",
    "dcc": "^14-17",
    "cc": 121
  },
  {
    "categorie": "^Child Neglect",
    "dcc": "^18-24",
    "cc": 6
  },
  {
    "categorie": "^Child Neglect",
    "dcc": "^31-45",
    "cc": 1
  },
  {
    "categorie": "^Child Neglect",
    "dcc": "^46-59",
    "cc": 1
  },
  {
    "categorie": "^Child Neglect",
    "dcc": "^Unknown",
    "cc": 3
  },
  {
    "categorie": "^Child to Child Sex",
    "dcc": "",
    "cc": 8
  },
  {
    "categorie": "^Child to Child Sex",
    "dcc": "^0-04",
    "cc": 2
  },
  {
    "categorie": "^Child to Child Sex",
    "dcc": "^05-09",
    "cc": 1
  },
  {
    "categorie": "^Child to Child Sex",
    "dcc": "^14-17",
    "cc": 2
  },
  {
    "categorie": "^Differently_Abled_Persons",
    "dcc": "",
    "cc": 1
  },
  {
    "categorie": "^Discrimination",
    "dcc": "",
    "cc": 2
  },
  {
    "categorie": "^Economic Violence",
    "dcc": "",
    "cc": 49
  },
  {
    "categorie": "^Economic Violence",
    "dcc": "^0-04",
    "cc": 10
  },
  {
    "categorie": "^Economic Violence",
    "dcc": "^05-09",
    "cc": 2
  },
  {
    "categorie": "^Economic Violence",
    "dcc": "^10-13",
    "cc": 2
  },
  {
    "categorie": "^Economic Violence",
    "dcc": "^14-17",
    "cc": 3
  },
  {
    "categorie": "^Economic Violence",
    "dcc": "^18-24",
    "cc": 3
  },
  {
    "categorie": "^Economic Violence",
    "dcc": "^25-30",
    "cc": 2
  },
  {
    "categorie": "^Economic Violence",
    "dcc": "^31-45",
    "cc": 1
  },
  {
    "categorie": "^Economic Violence",
    "dcc": "^46-59",
    "cc": 3
  },
  {
    "categorie": "^Emotional & Psychological Abuse",
    "dcc": "",
    "cc": 16
  },
  {
    "categorie": "^Emotional & Psychological Abuse",
    "dcc": "^0-04",
    "cc": 5
  },
  {
    "categorie": "^Emotional & Psychological Abuse",
    "dcc": "^05-09",
    "cc": 1
  },
  {
    "categorie": "^Emotional & Psychological Abuse",
    "dcc": "^10-13",
    "cc": 2
  },
  {
    "categorie": "^Emotional & Psychological Abuse",
    "dcc": "^14-17",
    "cc": 7
  },
  {
    "categorie": "^Emotional & Psychological Abuse",
    "dcc": "^18-24",
    "cc": 1
  },
  {
    "categorie": "^Emotional & Psychological Abuse",
    "dcc": "^25-30",
    "cc": 2
  },
  {
    "categorie": "^Emotional & Psychological Abuse",
    "dcc": "^31-45",
    "cc": 4
  },
  {
    "categorie": "^Employment\\\\\\/Job",
    "dcc": "",
    "cc": 1
  },
  {
    "categorie": "^Family Issues",
    "dcc": "",
    "cc": 28
  },
  {
    "categorie": "^Family Issues",
    "dcc": "^0-04",
    "cc": 14
  },
  {
    "categorie": "^Family Issues",
    "dcc": "^05-09",
    "cc": 8
  },
  {
    "categorie": "^Family Issues",
    "dcc": "^10-13",
    "cc": 1
  },
  {
    "categorie": "^Family Issues",
    "dcc": "^14-17",
    "cc": 1
  },
  {
    "categorie": "^Family Issues",
    "dcc": "^18-24",
    "cc": 2
  },
  {
    "categorie": "^Family Issues",
    "dcc": "^25-30",
    "cc": 2
  },
  {
    "categorie": "^Family Issues",
    "dcc": "^31-45",
    "cc": 4
  },
  {
    "categorie": "^Family Issues",
    "dcc": "^46-59",
    "cc": 3
  },
  {
    "categorie": "^Financial Aid",
    "dcc": "",
    "cc": 18
  },
  {
    "categorie": "^Financial Aid",
    "dcc": "^0-04",
    "cc": 4
  },
  {
    "categorie": "^Financial Aid",
    "dcc": "^05-09",
    "cc": 1
  },
  {
    "categorie": "^Financial Aid",
    "dcc": "^10-13",
    "cc": 1
  },
  {
    "categorie": "^Financial Aid",
    "dcc": "^14-17",
    "cc": 2
  },
  {
    "categorie": "^Harmful Tranditional Practices",
    "dcc": "",
    "cc": 35
  },
  {
    "categorie": "^Harmful Tranditional Practices",
    "dcc": "^05-09",
    "cc": 2
  },
  {
    "categorie": "^Harmful Tranditional Practices",
    "dcc": "^10-13",
    "cc": 3
  },
  {
    "categorie": "^Harmful Tranditional Practices",
    "dcc": "^14-17",
    "cc": 17
  },
  {
    "categorie": "^In Need of School Fees",
    "dcc": "",
    "cc": 62
  },
  {
    "categorie": "^In Need of School Fees",
    "dcc": "^05-09",
    "cc": 8
  },
  {
    "categorie": "^In Need of School Fees",
    "dcc": "^10-13",
    "cc": 7
  },
  {
    "categorie": "^In Need of School Fees",
    "dcc": "^14-17",
    "cc": 29
  },
  {
    "categorie": "^In Need of School Fees",
    "dcc": "^18-24",
    "cc": 3
  },
  {
    "categorie": "^Information on Helpline Services",
    "dcc": "",
    "cc": 16
  },
  {
    "categorie": "^Information on Helpline Services",
    "dcc": "^14-17",
    "cc": 3
  },
  {
    "categorie": "^Information on Helpline Services",
    "dcc": "^18-24",
    "cc": 1
  },
  {
    "categorie": "^Information on Helpline Services",
    "dcc": "^25-30",
    "cc": 1
  },
  {
    "categorie": "^Information on Helpline Services",
    "dcc": "^31-45",
    "cc": 1
  },
  {
    "categorie": "^Inquiry on Other Services",
    "dcc": "",
    "cc": 17
  },
  {
    "categorie": "^Inquiry on Other Services",
    "dcc": "^0-04",
    "cc": 2
  },
  {
    "categorie": "^Inquiry on Other Services",
    "dcc": "^05-09",
    "cc": 1
  },
  {
    "categorie": "^Inquiry on Other Services",
    "dcc": "^10-13",
    "cc": 1
  },
  {
    "categorie": "^Inquiry on Other Services",
    "dcc": "^18-24",
    "cc": 2
  },
  {
    "categorie": "^Inquiry on Other Services",
    "dcc": "^25-30",
    "cc": 1
  },
  {
    "categorie": "^Juvenile Deliquence",
    "dcc": "",
    "cc": 1
  },
  {
    "categorie": "^Juvenile Deliquence",
    "dcc": "^14-17",
    "cc": 1
  },
  {
    "categorie": "^Legal Issues",
    "dcc": "",
    "cc": 1
  },
  {
    "categorie": "^Legal_Issues",
    "dcc": "",
    "cc": 1
  },
  {
    "categorie": "^Legal_Issues",
    "dcc": "^14-17",
    "cc": 1
  },
  {
    "categorie": "^Lost Child",
    "dcc": "",
    "cc": 19
  },
  {
    "categorie": "^Lost Child",
    "dcc": "^0-04",
    "cc": 2
  },
  {
    "categorie": "^Lost Child",
    "dcc": "^05-09",
    "cc": 2
  },
  {
    "categorie": "^Lost Child",
    "dcc": "^10-13",
    "cc": 1
  },
  {
    "categorie": "^Lost Child",
    "dcc": "^14-17",
    "cc": 1
  },
  {
    "categorie": "^Medical Aid",
    "dcc": "",
    "cc": 6
  },
  {
    "categorie": "^Medical Aid",
    "dcc": "^10-13",
    "cc": 1
  },
  {
    "categorie": "^Medical Aid",
    "dcc": "^14-17",
    "cc": 1
  },
  {
    "categorie": "^Medical_Care",
    "dcc": "",
    "cc": 3
  },
  {
    "categorie": "^Medical_Care",
    "dcc": "^0-04",
    "cc": 1
  },
  {
    "categorie": "^Medical_Care",
    "dcc": "^05-09",
    "cc": 3
  },
  {
    "categorie": "^Medical_Care",
    "dcc": "^14-17",
    "cc": 1
  },
  {
    "categorie": "^Murder",
    "dcc": "",
    "cc": 5
  },
  {
    "categorie": "^Murder",
    "dcc": "^14-17",
    "cc": 1
  },
  {
    "categorie": "^Murder",
    "dcc": "^18-24",
    "cc": 1
  },
  {
    "categorie": "^Online Sexual Abuse & Violence",
    "dcc": "^14-17",
    "cc": 1
  },
  {
    "categorie": "^Online Sexual Abuse & Violence",
    "dcc": "^Unknown",
    "cc": 1
  },
  {
    "categorie": "^Orphans",
    "dcc": "",
    "cc": 28
  },
  {
    "categorie": "^Orphans",
    "dcc": "^05-09",
    "cc": 6
  },
  {
    "categorie": "^Orphans",
    "dcc": "^10-13",
    "cc": 4
  },
  {
    "categorie": "^Orphans",
    "dcc": "^14-17",
    "cc": 8
  },
  {
    "categorie": "^Orphans",
    "dcc": "^18-24",
    "cc": 1
  },
  {
    "categorie": "^Others",
    "dcc": "",
    "cc": 8
  },
  {
    "categorie": "^Others",
    "dcc": "^0-04",
    "cc": 5
  },
  {
    "categorie": "^Others",
    "dcc": "^05-09",
    "cc": 6
  },
  {
    "categorie": "^Others",
    "dcc": "^10-13",
    "cc": 6
  },
  {
    "categorie": "^Others",
    "dcc": "^14-17",
    "cc": 7
  },
  {
    "categorie": "^Others",
    "dcc": "^18-24",
    "cc": 1
  },
  {
    "categorie": "^Others",
    "dcc": "^46-59",
    "cc": 2
  },
  {
    "categorie": "^Parent or Child Relationship",
    "dcc": "",
    "cc": 16
  },
  {
    "categorie": "^Parent or Child Relationship",
    "dcc": "^05-09",
    "cc": 1
  },
  {
    "categorie": "^Parent or Child Relationship",
    "dcc": "^10-13",
    "cc": 4
  },
  {
    "categorie": "^Parent or Child Relationship",
    "dcc": "^14-17",
    "cc": 3
  },
  {
    "categorie": "^Parental Guidance",
    "dcc": "^14-17",
    "cc": 1
  },
  {
    "categorie": "^Physical Violence",
    "dcc": "",
    "cc": 168
  },
  {
    "categorie": "^Physical Violence",
    "dcc": "^0-04",
    "cc": 38
  },
  {
    "categorie": "^Physical Violence",
    "dcc": "^05-09",
    "cc": 55
  },
  {
    "categorie": "^Physical Violence",
    "dcc": "^10-13",
    "cc": 38
  },
  {
    "categorie": "^Physical Violence",
    "dcc": "^14-17",
    "cc": 25
  },
  {
    "categorie": "^Physical Violence",
    "dcc": "^18-24",
    "cc": 16
  },
  {
    "categorie": "^Physical Violence",
    "dcc": "^25-30",
    "cc": 5
  },
  {
    "categorie": "^Physical Violence",
    "dcc": "^31-45",
    "cc": 18
  },
  {
    "categorie": "^Property_Rights",
    "dcc": "",
    "cc": 31
  },
  {
    "categorie": "^Property_Rights",
    "dcc": "^0-04",
    "cc": 3
  },
  {
    "categorie": "^Property_Rights",
    "dcc": "^05-09",
    "cc": 7
  },
  {
    "categorie": "^Property_Rights",
    "dcc": "^10-13",
    "cc": 1
  },
  {
    "categorie": "^Property_Rights",
    "dcc": "^14-17",
    "cc": 2
  },
  {
    "categorie": "^Property_Rights",
    "dcc": "^31-45",
    "cc": 1
  },
  {
    "categorie": "^Reproductive Health Issues",
    "dcc": "^18-24",
    "cc": 1
  },
  {
    "categorie": "^Reproductive Health Issues",
    "dcc": "^25-30",
    "cc": 1
  },
  {
    "categorie": "^Run Away Child",
    "dcc": "",
    "cc": 4
  },
  {
    "categorie": "^Run Away Child",
    "dcc": "^05-09",
    "cc": 1
  },
  {
    "categorie": "^Run Away Child",
    "dcc": "^10-13",
    "cc": 2
  },
  {
    "categorie": "^Run Away Child",
    "dcc": "^14-17",
    "cc": 2
  },
  {
    "categorie": "^Sexual Violence",
    "dcc": "",
    "cc": 87
  },
  {
    "categorie": "^Sexual Violence",
    "dcc": "^0-04",
    "cc": 6
  },
  {
    "categorie": "^Sexual Violence",
    "dcc": "^05-09",
    "cc": 15
  },
  {
    "categorie": "^Sexual Violence",
    "dcc": "^10-13",
    "cc": 30
  },
  {
    "categorie": "^Sexual Violence",
    "dcc": "^14-17",
    "cc": 72
  },
  {
    "categorie": "^Sexual Violence",
    "dcc": "^18-24",
    "cc": 5
  },
  {
    "categorie": "^Sexual Violence",
    "dcc": "^25-30",
    "cc": 2
  },
  {
    "categorie": "^Sexual Violence",
    "dcc": "^46-59",
    "cc": 1
  },
  {
    "categorie": "^Sexual Violence",
    "dcc": "^Unknown",
    "cc": 1
  },
  {
    "categorie": "^Street Child",
    "dcc": "",
    "cc": 1
  },
  {
    "categorie": "^Topical Issues (Child rights, Biology etc)",
    "dcc": "",
    "cc": 19
  },
  {
    "categorie": "^Topical Issues (Child rights, Biology etc)",
    "dcc": "^0-04",
    "cc": 8
  },
  {
    "categorie": "^Topical Issues (Child rights, Biology etc)",
    "dcc": "^05-09",
    "cc": 4
  },
  {
    "categorie": "^Topical Issues (Child rights, Biology etc)",
    "dcc": "^10-13",
    "cc": 5
  },
  {
    "categorie": "^Topical Issues (Child rights, Biology etc)",
    "dcc": "^14-17",
    "cc": 4
  },
  {
    "categorie": "^Topical Issues (Child rights, Biology etc)",
    "dcc": "^18-24",
    "cc": 2
  },
  {
    "categorie": "^Topical Issues (Child rights, Biology etc)",
    "dcc": "^25-30",
    "cc": 1
  },
  {
    "categorie": "^Trafficking in Persons",
    "dcc": "",
    "cc": 29
  },
  {
    "categorie": "^Trafficking in Persons",
    "dcc": "^0-04",
    "cc": 1
  },
  {
    "categorie": "^Trafficking in Persons",
    "dcc": "^05-09",
    "cc": 3
  },
  {
    "categorie": "^Trafficking in Persons",
    "dcc": "^10-13",
    "cc": 3
  },
  {
    "categorie": "^Trafficking in Persons",
    "dcc": "^14-17",
    "cc": 7
  }
]
